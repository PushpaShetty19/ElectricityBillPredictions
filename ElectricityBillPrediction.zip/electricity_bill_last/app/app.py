import streamlit as st
import pandas as pd
import numpy as np
import pickle
import os
import matplotlib.pyplot as plt

# Load model and encoders
model = pickle.load(open('models/bill_predictor.pkl', 'rb'))
le_state = pickle.load(open('models/state_encoder.pkl', 'rb'))
le_month = pickle.load(open('models/month_encoder.pkl', 'rb'))

# Streamlit app setup
st.set_page_config(page_title="Electricity Bill Predictor", layout="centered")
st.title("⚡ Smart Electricity Bill Predictor")

st.sidebar.title("📂 Upload & Analyze")
uploaded_file = st.sidebar.file_uploader("Upload past bills CSV (Optional)", type=["csv"])

if uploaded_file:
    df_upload = pd.read_csv(uploaded_file)
    st.sidebar.success("✅ File uploaded successfully!")
    st.subheader("📊 Your Past Bill Data")
    st.dataframe(df_upload)

    # Predict future bill (for next month)
    if 'Units_Consumed' in df_upload.columns:
        last_units = df_upload['Units_Consumed'].iloc[-1]
        st.info(f"🔮 Based on last month usage ({last_units} units):")

        state = st.selectbox("Select Your State", le_state.classes_)
        month = st.selectbox("Predict For Month", le_month.classes_)
        state_encoded = le_state.transform([state])[0]
        month_encoded = le_month.transform([month])[0]
        input_data = np.array([[state_encoded, month_encoded, last_units]])
        pred = model.predict(input_data)[0]
        st.success(f"📈 Predicted Bill: ₹{pred:.2f}")

    # Trend Chart
    if 'Month' in df_upload.columns and 'Bill' in df_upload.columns:
        fig, ax = plt.subplots()
        df_upload.plot(x='Month', y='Bill', kind='line', marker='o', ax=ax)
        plt.title("📉 Monthly Bill Trend")
        plt.ylabel("Bill (₹)")
        st.pyplot(fig)

st.header("🔢 Manual Prediction")

# Manual Prediction Inputs
col1, col2 = st.columns(2)
with col1:
    state_input = st.selectbox("State", le_state.classes_)
    month_input = st.selectbox("Month", le_month.classes_)
with col2:
    units = st.number_input("Units Consumed", min_value=0)

if st.button("💡 Predict Now"):
    state_enc = le_state.transform([state_input])[0]
    month_enc = le_month.transform([month_input])[0]
    features = np.array([[state_enc, month_enc, units]])
    prediction = model.predict(features)[0]
    st.success(f"💰 Estimated Electricity Bill: ₹{prediction:.2f}")

