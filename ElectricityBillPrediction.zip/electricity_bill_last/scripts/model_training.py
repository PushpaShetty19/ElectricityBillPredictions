import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import pickle
import os

df = pd.read_csv('data/electricity_data.csv')

le_state = LabelEncoder()
le_month = LabelEncoder()
df['State'] = le_state.fit_transform(df['State'])
df['Month'] = le_month.fit_transform(df['Month'])

X = df[['State', 'Month', 'Units_Consumed']]
y = df['Bill']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestRegressor()
model.fit(X_train, y_train)

os.makedirs('models', exist_ok=True)
pickle.dump(model, open('models/bill_predictor.pkl', 'wb'))
pickle.dump(le_state, open('models/state_encoder.pkl', 'wb'))
pickle.dump(le_month, open('models/month_encoder.pkl', 'wb'))

print("✅ Model trained and saved.")
