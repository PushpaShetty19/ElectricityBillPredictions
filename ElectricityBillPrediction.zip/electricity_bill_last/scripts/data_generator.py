import pandas as pd
import random

states = ['Karnataka', 'Maharashtra', 'Delhi', 'Tamil Nadu']
months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
tariff_rates = {
    'Karnataka': [0, 100, 200],      # Slabs in units
    'Maharashtra': [0, 100, 300],
    'Delhi': [0, 150, 400],
    'Tamil Nadu': [0, 200, 400]
}
slab_prices = {
    'Karnataka': [3, 5, 7],
    'Maharashtra': [4, 6, 8],
    'Delhi': [3.5, 5.5, 7],
    'Tamil Nadu': [2.5, 4.5, 6]
}

def calculate_bill(units, slabs, prices):
    bill = 0
    if units <= slabs[1]:
        bill += units * prices[0]
    elif units <= slabs[2]:
        bill += slabs[1] * prices[0] + (units - slabs[1]) * prices[1]
    else:
        bill += (slabs[1] * prices[0]) + ((slabs[2]-slabs[1]) * prices[1]) + ((units - slabs[2]) * prices[2])
    return bill + 50  # fixed charge

data = []
for _ in range(1000):
    state = random.choice(states)
    month = random.choice(months)
    units = random.randint(50, 600)
    slabs = tariff_rates[state]
    prices = slab_prices[state]
    bill = calculate_bill(units, slabs, prices)
    data.append([state, month, units, bill])

df = pd.DataFrame(data, columns=['State', 'Month', 'Units_Consumed', 'Bill'])
df.to_csv('data/electricity_data.csv', index=False)
